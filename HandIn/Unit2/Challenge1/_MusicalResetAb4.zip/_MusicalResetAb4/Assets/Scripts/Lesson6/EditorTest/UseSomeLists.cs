using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UseSomeLists : MonoBehaviour
{
    public BoxCollider[] m_boxColliders;
}
