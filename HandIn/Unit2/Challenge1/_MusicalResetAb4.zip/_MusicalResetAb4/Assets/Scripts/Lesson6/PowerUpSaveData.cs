using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MusicalRunes;

// not needed and more -> SaveData

/*

public class PowerUpSaveDataBase : MonoBehaviour
{
    public PowerUpType Type;
    public int Level;
}
*/
