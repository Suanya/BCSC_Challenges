
public interface IHurtable
{
    void GetHit();
}
